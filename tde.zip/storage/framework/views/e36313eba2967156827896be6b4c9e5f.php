

<?php $__env->startSection('title', 'User Details - ' . $user->name); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6">
    
    <!-- Back Button -->
    <div class="mb-6">
        <a href="<?php echo e(route('admin.users.index')); ?>" class="text-primary hover:text-primary/80 inline-flex items-center">
            <i class="fas fa-arrow-left mr-2"></i>
            Back to Users
        </a>
    </div>

    <!-- User Profile Card -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <div class="flex items-start justify-between">
            <div class="flex items-center space-x-4">
                <div class="w-20 h-20 rounded-full bg-primary flex items-center justify-center text-white font-bold text-2xl">
                    <?php echo e(substr($user->name, 0, 1)); ?>

                </div>
                <div>
                    <h1 class="text-2xl font-bold text-gray-900"><?php echo e($user->name); ?></h1>
                    <p class="text-gray-600"><?php echo e($user->email); ?></p>
                    <div class="flex items-center space-x-2 mt-2">
                        <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo e($user->role === 'agent' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800'); ?>">
                            <?php echo e(ucfirst($user->role)); ?>

                        </span>
                        <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo e(membership_badge_color($user->membershipTier->level)); ?>">
                            <?php echo e($user->membershipTier->name); ?>

                        </span>
                        <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo e(status_badge_color($user->status)); ?>">
                            <?php echo e(ucfirst($user->status)); ?>

                        </span>
                    </div>
                </div>
            </div>
            <div class="text-right">
                <p class="text-sm text-gray-600">Referral Code</p>
                <p class="text-xl font-bold text-primary"><?php echo e($user->referral_code); ?></p>
            </div>
        </div>

        <?php if($user->referrer): ?>
            <div class="mt-4 pt-4 border-t border-gray-200">
                <p class="text-sm text-gray-600">
                    Referred by: <a href="<?php echo e(route('admin.users.show', $user->referrer)); ?>" class="text-primary hover:underline font-semibold"><?php echo e($user->referrer->name); ?></a>
                </p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Point Balance</p>
                    <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo e(number_format($user->point_balance, 2)); ?></p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-coins text-green-600 text-xl"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Total Tasks</p>
                    <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo e($stats['total_tasks']); ?></p>
                    <p class="text-sm text-gray-500 mt-1">
                        <span class="text-yellow-600 font-semibold"><?php echo e($stats['pending_tasks']); ?></span> pending
                    </p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-tasks text-blue-600 text-xl"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Total Earned</p>
                    <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo e(number_format($stats['total_earned'], 2)); ?></p>
                </div>
                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-chart-line text-purple-600 text-xl"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600">Referrals</p>
                    <p class="text-3xl font-bold text-gray-900 mt-2"><?php echo e($stats['total_referrals']); ?></p>
                    <p class="text-sm text-gray-500 mt-1">
                        <span class="text-green-600 font-semibold"><?php echo e(number_format($stats['referral_earnings'], 2)); ?></span> earned
                    </p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-users text-yellow-600 text-xl"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Task Queue -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-lg font-semibold text-gray-900">Task Queue</h2>
                <a href="<?php echo e(route('admin.task-queue.user.queue', $user)); ?>" class="text-sm text-primary hover:text-primary/80">View All</a>
            </div>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $user->taskQueues->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskQueue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex-1">
                            <p class="text-sm font-medium text-gray-900"><?php echo e($taskQueue->product->name); ?></p>
                            <p class="text-xs text-gray-500 mt-1">
                                Points: <?php echo e(number_format($taskQueue->product->base_points)); ?> | 
                                Commission: <?php echo e(number_format($taskQueue->product->calculateCommission($user))); ?>

                            </p>
                        </div>
                        <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo e(status_badge_color($taskQueue->status)); ?>">
                            <?php echo e(ucfirst($taskQueue->status)); ?>

                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-center py-4">No tasks in queue</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Tasks -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 class="text-lg font-semibold text-gray-900 mb-4">Recent Tasks</h2>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $user->tasks->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between p-3 border-l-4 <?php echo e($task->status === 'completed' ? 'border-green-500 bg-green-50' : 'border-yellow-500 bg-yellow-50'); ?>">
                        <div class="flex-1">
                            <p class="text-sm font-medium text-gray-900"><?php echo e($task->product->name); ?></p>
                            <p class="text-xs text-gray-600">
                                Commission: <?php echo e(number_format($task->commission_earned)); ?> points
                            </p>
                            <p class="text-xs text-gray-500 mt-1"><?php echo e($task->created_at->diffForHumans()); ?></p>
                        </div>
                        <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo e(status_badge_color($task->status)); ?>">
                            <?php echo e(ucfirst($task->status)); ?>

                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-center py-4">No tasks completed</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Transactions -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 lg:col-span-2">
            <h2 class="text-lg font-semibold text-gray-900 mb-4">Recent Transactions</h2>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Balance</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $user->transactions->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3">
                                    <span class="text-xs font-medium text-gray-700">
                                        <?php echo e(transaction_type_label($transaction->type)); ?>

                                    </span>
                                </td>
                                <td class="px-4 py-3">
                                    <span class="text-sm font-semibold <?php echo e($transaction->amount >= 0 ? 'text-green-600' : 'text-red-600'); ?>">
                                        <?php echo e($transaction->amount >= 0 ? '+' : ''); ?><?php echo e(number_format($transaction->amount, 2)); ?>

                                    </span>
                                </td>
                                <td class="px-4 py-3 text-sm text-gray-900">
                                    <?php echo e(number_format($transaction->balance_after, 2)); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-gray-600">
                                    <?php echo e($transaction->description); ?>

                                </td>
                                <td class="px-4 py-3 text-sm text-gray-500">
                                    <?php echo e($transaction->created_at->format('M d, H:i')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="px-4 py-8 text-center text-gray-500">
                                    No transactions yet
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Referrals -->
        <?php if($user->referrals->count() > 0): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 lg:col-span-2">
                <h2 class="text-lg font-semibold text-gray-900 mb-4">Referrals (<?php echo e($user->referrals->count()); ?>)</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <?php $__currentLoopData = $user->referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('admin.users.show', $referral)); ?>" 
                           class="p-4 border border-gray-200 rounded-lg hover:border-primary hover:shadow-sm transition">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-semibold">
                                    <?php echo e(substr($referral->name, 0, 1)); ?>

                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-medium text-gray-900 truncate"><?php echo e($referral->name); ?></p>
                                    <p class="text-xs text-gray-500"><?php echo e($referral->membershipTier->name); ?></p>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\project\TDE\resources\views/admin/users/show.blade.php ENDPATH**/ ?>