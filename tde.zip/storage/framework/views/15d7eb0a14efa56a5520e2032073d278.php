

<?php $__env->startSection('title', 'Bonus History'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="transactionPage()" class="space-y-4">
    
    <!-- Page Title -->
    <div class="flex items-center justify-between">
        <h1 class="text-2xl font-bold text-gray-900">Bonus History</h1>

        <a href="<?php echo e(route('dashboard')); ?>" 
        class="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl text-white text-sm font-bold shadow-lg hover:shadow-xl transition">
            <i class="fas fa-arrow-left"></i>
            <span>Dashboard</span>
        </a>
    </div>

    <!-- Orange Divider Line -->
    <div class="w-full h-1 bg-gradient-to-r from-orange-500 to-orange-400"></div>

    <!-- Filter Tabs -->
    <div class="flex bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <button @click="activeFilter = 'recharge'" 
                :class="activeFilter === 'recharge' ? 'border-b-2 border-orange-500 text-gray-900 font-bold' : 'text-gray-500'"
                class="flex-1 py-3 text-sm transition">
            Recharge
        </button>
        <button @click="activeFilter = 'withdrawal'" 
                :class="activeFilter === 'withdrawal' ? 'border-b-2 border-orange-500 text-gray-900 font-bold' : 'text-gray-500'"
                class="flex-1 py-3 text-sm transition">
            Withdrawal
        </button>
        <button @click="activeFilter = 'commission'" 
                :class="activeFilter === 'commission' ? 'border-b-2 border-orange-500 text-gray-900 font-bold' : 'text-gray-500'"
                class="flex-1 py-3 text-sm transition">
            Commission History
        </button>
    </div>

    <!-- Transactions List -->
    <div class="space-y-4">
        <template x-for="transaction in filteredTransactions" :key="transaction.id">
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                <!-- Transaction Details -->
                <div class="space-y-2 text-sm">
                    <div class="flex justify-between">
                        <span class="text-gray-600 font-medium">ORDER NUMBER:</span>
                        <span class="text-gray-900 font-mono text-xs break-all max-w-[60%] text-right" x-text="transaction.order_number"></span>
                    </div>
                    
                    <div class="flex justify-between">
                        <span class="text-gray-600 font-medium">AMOUNT:</span>
                        <span class="font-bold" 
                              :class="transaction.amount >= 0 ? 'text-green-600' : 'text-red-600'"
                              x-text="transaction.amount"></span>
                    </div>
                    
                    <template x-if="transaction.status">
                        <div class="flex justify-between">
                            <span class="text-gray-600 font-medium">STATUS:</span>
                            <span class="font-bold" 
                                  :class="transaction.status === 'SUCCESS' ? 'text-green-600' : 'text-yellow-600'"
                                  x-text="transaction.status"></span>
                        </div>
                    </template>
                    
                    <template x-if="transaction.commission_type">
                        <div class="flex justify-between">
                            <span class="text-gray-600 font-medium">COMMISSION:</span>
                            <span class="text-gray-900 font-semibold" x-text="transaction.commission_type"></span>
                        </div>
                    </template>
                    
                    <div class="flex justify-between pt-2 border-t border-gray-200">
                        <span class="text-gray-600 font-medium">CREATE TIME:</span>
                        <span class="text-gray-500 text-xs" x-text="transaction.created_at"></span>
                    </div>
                </div>
            </div>
        </template>

        <!-- No Data -->
        <template x-if="filteredTransactions.length === 0">
            <div class="py-16 text-center">
                <p class="text-gray-400 text-sm">No Data Available</p>
            </div>
        </template>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function transactionPage() {
        return {
            activeFilter: 'recharge',
            transactions: [],
            loading: true,

            init() {
                this.fetchTransactions();
            },

            get filteredTransactions() {
                return this.transactions.filter(tx => tx.type === this.activeFilter);
            },

            async fetchTransactions() {
                try {
                    showLoading('Loading transactions...');
                    const response = await axios.get('<?php echo e(route("transactions.history")); ?>');
                    
                    if (response.data.success) {
                        this.transactions = response.data.transactions;
                    }
                    
                    hideLoading();
                } catch (error) {
                    hideLoading();
                    console.error('Error fetching transactions:', error);
                    showAlert('Error loading transactions', 'error');
                }
            }
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\project\TDE\resources\views/transactions/index.blade.php ENDPATH**/ ?>