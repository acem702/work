<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('membership_tiers', function (Blueprint $table) {
            $table->string('icon')->nullable()->after('description');
            // Icon will store Font Awesome class names like "fa-crown", "fa-gem", etc.
        });
    }

    public function down()
    {
        Schema::table('membership_tiers', function (Blueprint $table) {
            $table->dropColumn('icon');
        });
    }
};