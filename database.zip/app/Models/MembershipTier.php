<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class MembershipTier extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'level',
        'daily_task_limit',
        'commission_multiplier',
        'upgrade_cost',
        'description',
        'icon',
        'is_active'
    ];

    protected $casts = [
        'commission_multiplier' => 'decimal:2',
        'upgrade_cost' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    protected static function boot()
    {
        parent::boot();

        // Auto-generate slug from name
        static::creating(function ($tier) {
            if (empty($tier->slug)) {
                $tier->slug = Str::slug($tier->name);
            }
        });

        static::updating(function ($tier) {
            if ($tier->isDirty('name')) {
                $tier->slug = Str::slug($tier->name);
            }
        });
    }

    // Relationships
    public function users()
    {
        return $this->hasMany(User::class);
    }

    public function products()
    {
        return $this->hasMany(Product::class, 'min_membership_tier_id');
    }

    public function comboTasks()
    {
        return $this->hasManyThrough(
            ComboTask::class,
            Product::class,
            'min_membership_tier_id', // Foreign key on products table
            'id', // Foreign key on combo_tasks table
            'id', // Local key on membership_tiers table
            'id' // Local key on products table
        );
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('level');
    }

    // Methods
    public function getNextTier()
    {
        return self::where('level', '>', $this->level)
            ->where('is_active', true)
            ->orderBy('level')
            ->first();
    }

    public function getIconHtmlAttribute()
    {
        return $this->icon ? '<i class="fas ' . $this->icon . '"></i>' : '<i class="fas fa-user"></i>';
    }

    public function getActiveUsersCountAttribute()
    {
        return $this->users()->where('status', 'active')->count();
    }

    public function getAccessibleProductsCountAttribute()
    {
        return Product::whereHas('minMembershipTier', fn($q) => 
            $q->where('level', '<=', $this->level)
        )->count();
    }
}