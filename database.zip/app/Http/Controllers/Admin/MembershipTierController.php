<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MembershipTier;
use Illuminate\Http\Request;
use Exception;

class MembershipTierController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display membership tiers management page
     */
    public function index()
    {
        $tiers = MembershipTier::withCount(['users' => function ($query) {
            $query->where('status', 'active');
        }])->ordered()->get();

        return view('admin.membership-tiers.index', compact('tiers'));
    }

    /**
     * Store a new membership tier
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'level' => 'required|integer|min:1|unique:membership_tiers,level',
            'daily_task_limit' => 'required|integer|min:1',
            'commission_multiplier' => 'required|numeric|min:0.1',
            'upgrade_cost' => 'required|numeric|min:0',
            'description' => 'nullable|string',
            'icon' => 'nullable|string|max:100',
        ]);

        try {
            $tier = MembershipTier::create([
                'name' => $request->name,
                'level' => $request->level,
                'daily_task_limit' => $request->daily_task_limit,
                'commission_multiplier' => $request->commission_multiplier,
                'upgrade_cost' => $request->upgrade_cost,
                'description' => $request->description,
                'icon' => $request->icon,
                'is_active' => true,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Membership tier created successfully',
                'tier' => $tier,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Update membership tier
     */
    public function update(Request $request, MembershipTier $membershipTier)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'level' => 'required|integer|min:1|unique:membership_tiers,level,' . $membershipTier->id,
            'daily_task_limit' => 'required|integer|min:1',
            'commission_multiplier' => 'required|numeric|min:0.1',
            'upgrade_cost' => 'required|numeric|min:0',
            'description' => 'nullable|string',
            'icon' => 'nullable|string|max:100',
        ]);

        try {
            $membershipTier->update([
                'name' => $request->name,
                'level' => $request->level,
                'daily_task_limit' => $request->daily_task_limit,
                'commission_multiplier' => $request->commission_multiplier,
                'upgrade_cost' => $request->upgrade_cost,
                'description' => $request->description,
                'icon' => $request->icon,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Membership tier updated successfully',
                'tier' => $membershipTier->fresh(),
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Delete membership tier
     */
    public function destroy(MembershipTier $membershipTier)
    {
        try {
            // Check if tier has active users
            $activeUsersCount = $membershipTier->users()->where('status', 'active')->count();
            
            if ($activeUsersCount > 0) {
                return response()->json([
                    'success' => false,
                    'message' => "Cannot delete tier with {$activeUsersCount} active users. Please reassign users first.",
                ], 400);
            }

            // Check if tier is referenced by products
            $productsCount = $membershipTier->products()->count();
            
            if ($productsCount > 0) {
                return response()->json([
                    'success' => false,
                    'message' => "Cannot delete tier referenced by {$productsCount} products. Please update products first.",
                ], 400);
            }

            $membershipTier->delete();

            return response()->json([
                'success' => true,
                'message' => 'Membership tier deleted successfully',
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Toggle tier status
     */
    public function toggleStatus(MembershipTier $membershipTier)
    {
        try {
            $membershipTier->update(['is_active' => !$membershipTier->is_active]);

            return response()->json([
                'success' => true,
                'message' => 'Status updated successfully',
                'is_active' => $membershipTier->is_active,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }
}